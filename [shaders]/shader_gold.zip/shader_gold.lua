function startShaderResource()
	local ref_shader, technique = dxCreateShader ( "shader_gold.fx" )

	local textureBumb = dxCreateTexture ( "textures/Default_bump_normal.dds" );
	local textureReflect = dxCreateTexture ( "textures/Default_reflection.dds" );
	dxSetShaderValue ( ref_shader, "sRandomTexture", textureBumb );
	dxSetShaderValue ( ref_shader, "sReflectionTexture", textureReflect );


	engineApplyShaderToWorldTexture ( ref_shader, "vehiclegrunge256" )
	engineApplyShaderToWorldTexture ( ref_shader, "?emap*" )
end

addEventHandler( "onClientResourceStart", getRootElement(), startShaderResource )